#---------------------------------------------------------------------
package Ini;

use 5.008000;
use strict;
use warnings;
use Carp;

=head1 NAME

Ini - ini-style configuration file reader

=head1 VERSION

This document refers to version 0.01 of Ini,
released January 10, 2006.

=head1 SYNOPSIS

 use Ini;

 my $ini = Ini->new( 'file.ini' );

 # traverse the values
 for my $section ( $ini->get_sections() ) {
     print "$section\n";

     for my $name ( $ini->get_names( $section ) ) {
         print "  $name\n";

         for my $value ( $ini->get( $section, $name ) ) {
             print "    $value\n";
         }
     }
 }

=cut

# more POD follows the __END__

our @ISA = qw();

our $VERSION = '0.01';

use Text::ParseWords;

# methods summary:
# $ini = Ini->new( file=>$file, fh=>$fh, string=>$string )
# $ini->init( file=>$file, fh=>$fh, string=>$string )
# $ini->add( $section, $name, @values )
# $ini->get( $section, $name, $i )
# $ini->get_aref( $section, $name )
# $ini->add_section( $section )
# $ini->get_sections()
# $ini->get_names( $section )

use constant SECTIONS => 0;
use constant SHASH    => 1;
use constant ATTRS    => 2;
use constant NAMES  => 0;
use constant NHASH  => 1;
use constant VALS => 0; # because we'll have CMTS => 1 in Ini::Edit

# object structure summary:
#           [
# SECTIONS:     [ 'section1', ],
# SHASH:        {
#                   section1 => [
#     NAMES:            [ 'name1', ],
#     NHASH:            {
#                           name1 => [
#         VALS:                 [ $value1, ],
#                           ],
#                       },
#                   ],
#               },
# ATTRS:        { ... },
#           ],

#---------------------------------------------------------------------
## $ini = Ini->new( $file )             or
## $ini = Ini->new( file   => $file   ) or
## $ini = Ini->new( fh     => $fh     ) or
## $ini = Ini->new( string => $string )
sub new {
    my ( $class, @parms ) = @_;
    my $self  = [];
    bless $self, $class;
    $self->init( @parms ) if @parms;
    return $self;
}

#---------------------------------------------------------------------
## $ini->init( $file )            or
## $ini->init( file   => $file   ) or
## $ini->init( fh     => $fh     ) or
## $ini->init( string => $string )
sub init {
    my ( $self, @parms ) = @_;

    my ( $file, $fh, $string );
    if( @parms == 1 ) {
        $file   = $parms[0]; }
    else {
        my %parms = @parms;
        $file   = $parms{'file'};
        $fh     = $parms{'fh'};
        $string = $parms{'string'}; }
    $self->[ATTRS]{'file'} = $file if $file;

    unless( $fh ) {
        if( $string ) {
            open $fh, '<', \$string
                or croak "Can't open string: $!"; }
        elsif( $file ) {
            open $fh, '<', $file
                or croak "Can't open $file: $!"; }
        else { croak "Invalid parms" }
    }

    my $section = '';
    my $name = '';
    my $value;

    local *_;
    while( <$fh> ) {
        my $parse = '';

        # comment or blank line
        if( /^\s*[#;]/ or /^\s*$/ ) {
            next;
        }

        # [section]
        if( /^\[([^{}\]]+)\]/ ) {
            $section = $1;
            $self->add_section( $1 );
            next;
        }  # if

        # <<heredoc
        # Note: name = {xyz} must not be seen as a heredoc
        elsif( /^\s*(.+?)\s*[=:]\s*(<<|{)\s*([^}]*?)\s*$/ ) {
            $name = $1;
            $value = '';
            my $endtag = (
                $2 eq '<<' ? '<<' :
                $2 eq '{'  ? '}'  : die );
            my $heretag = $3;
            my $exdent = ($heretag =~ s/\s*:exdent\s*//i ) ? 1 : '';
            my $join   = ($heretag =~ s/\s*:join\s*// )    ? 1 : '';
            my $chomp  = ($heretag =~ s/\s*:chomp\s*//)    ? 1 : '';
            $parse = $1   if $heretag =~ s/\s*:parse\s*\(\s*(.*?)\s*\)\s*//;
            $parse = '\n' if $heretag =~ s/\s*:parse\s*//;
            my $found;
            while( <$fh> ) {
                if( ( $heretag ne '' and
                    /^\s*(?:$endtag)*\s*\Q$heretag\E\s*$/ ) ||
                    ( $heretag eq '' and
                    /^\s*$endtag\s*$/ ) ) {
                    ++$found; last; }
                else { chomp $value if $join; }
                s/^\s+// if $exdent;
                $value .= $_;
            }  # while
            die "Didn't find heredoc end tag ($heretag) " .
                "for $section:$name" unless $found;
            # ':parse' enables ':chomp', too
            chomp $value if $chomp or $parse ne '';
        }  # elsif

        # name = value
        elsif( /^\s*(.+?)\s*[=:]\s*(.*)$/ ) {
            $name = $1;
            $value = $2;
        }

        # "bare word" (treated as boolean set to true(1))
        else {
            s/^\s+//g; s/\s+$//g;
            $name = $_;
            $value = 1;
        }

        if( $parse ne '' ) {
            $parse = $2 if $parse =~ /^(['"\/])(.*)\1$/; # dumb quotes
            $self->add( $section, $name,
                map { (defined $_) ? $_ : '' }
                parse_line( $parse, 0, $value ) ); }
        else {
            $self->add( $section, $name, $value ); }

    }  # while

}  # end sub init

#---------------------------------------------------------------------
## $ini->attr( $attribute, $value )
sub attr {
    my( $self, $attribute ) = ( shift, shift );
    return $self->[ATTRS]{ $attribute } unless @_;
    $self->[ATTRS]{ $attribute } = shift;
}

#---------------------------------------------------------------------
## $ini->add( $section, $name, @values )
sub add {
    my ( $self, $section, $name, @values ) = @_;
    return unless defined $section and defined $name;

    $self->add_section( $section ) unless $self->[SHASH]{ $section };

    push @{$self->[SHASH]{ $section }[NAMES]}, $name
        unless $self->[SHASH]{ $section }[NHASH]{ $name };
    push @{$self->[SHASH]{ $section }[NHASH]{ $name }[VALS]}, @values;
}

#---------------------------------------------------------------------
## $ini->get( $section, $name, $i )
sub get {
    my ( $self, $section, $name, $i ) = @_;
    return unless defined $section;
    ( $name = $section, $section = '' ) unless defined $name;

    my $aref = $self->[SHASH]{ $section }[NHASH]{ $name }[VALS];
    return unless $aref;
    return @$aref if wantarray;
    return $aref->[ $i ] if defined $i;
    return "@$aref";
}

#---------------------------------------------------------------------
## $ini->get_aref( $section, $name )
sub get_aref {
    my ( $self, $section, $name ) = @_;
    return unless defined $section;
    ( $name = $section, $section = '' ) unless defined $name;

    my $aref = $self->[SHASH]{ $section }[NHASH]{ $name }[VALS];
    return unless $aref;
    return $aref;
}

#---------------------------------------------------------------------
## $ini->add_section( $section )
sub add_section {
    my ( $self, $section ) = @_;
    return unless defined $section;

    # only add it once
    unless( $self->[SHASH]{ $section } ) {
        push @{$self->[SECTIONS]}, $section;
        $self->[SHASH]{ $section } = [];
        return 1;
    }
    return '';
}

#---------------------------------------------------------------------
## $ini->get_sections()
sub get_sections {
    my ( $self ) = @_;

    return unless defined $self->[SECTIONS];
    return @{$self->[SECTIONS]};
}

#---------------------------------------------------------------------
## $ini->get_names( $section )
sub get_names {
    my ( $self, $section ) = @_;
    return unless defined $section;

    return unless defined $self->[SHASH]{ $section }[NAMES];
    return @{$self->[SHASH]{ $section }[NAMES]};
}

#---------------------------------------------------------------------
1;

__END__

=head1 DESCRIPTION

This is yet another ini file processor.  The motivation
is simply that I have more control over the features I
add.

=head2 Terminology

 # comment
 [section]
 name = value

In particular 'name' is the term used to refer to the
named options within the sections.

=head2 Syntax

 # comments may begin with # or ;, i.e.,
 ; semicolon is valid comment character
 [section]
 # spaces/tabs around '=' are stripped
 # use heredoc to give a value with leading spaces
 # trailing spaces are left intact
 name=value
 name= value
 name =value
 name = value
 name    =    value

 # this is a comment
 [section] # this is a comment
 name = value # this is NOT a comment

 # colon is valid assignment character, too.
 name:value
 name: value
 name :value
 name : value
 name    :    value

 # classic heredoc
 name = <<heredoc
 Heredocs are supported several ways.
 heredoc

 # and because I kept doing this
 name = <<heredoc
 value
 <<heredoc

 # and because who cares what it's called
 name = <<
 value
 <<

 # and "block style" (for vi % support)
 name = {
 value
 }

 # and obscure variations, e.g.,
 name = {heredoc
 value
 heredoc

=head2 Heredoc :modifiers

There are several ways to modify the value
in a heredoc:

 :chomp  - chomps the last line
 :join   - chomps every line BUT the last one
 :exdent - unindents every line (strips leading whitespace)
 :parse  - splits on newline (chomps last line)
 :parse(regex) - splits on regex (still chomps last line)

The :parse modifier uses Text::ParseWords::parse_line(),
so CSV-like parsing is possible.

Modifiers may be stacked, e.g., <<:chomp:join:exdent,
in any order (but :parse is always done last).

 # $value == "Line1\nLine2\n" (unmodified)
 name = <<
 Line1
 Line2
 <<

 # $value == "Line1\nLine2"
 name = <<:chomp
 Line1
 Line2
 <<

 # $value == "Line1Line2\n"
 name = <<:join
 Line1
 Line2
 <<

 # $value == "Line1Line2"
 name = <<:chomp:join
 Line1
 Line2
 <<

 # $value == "  Line1\n  Line2\n" (unmodified)
 name = <<
   Line1
   Line2
 <<

 # - indentations do NOT have to be regular to be exdented
 # - any leading spaces/tabs on every line will be stripped
 # - trailing spaces are left intact, as usual
 # $value == "Line1\nLine2\n"
 name = <<:exdent
   Line1
   Line2
 <<

 # modifiers may have spaces between
 # $value == "Line1Line2"
 name = << :chomp :join :exdent
   Line1
   Line2
 <<

 # with heredoc "tag"
 # $value == "Line1Line2"
 name = <<heredoc :chomp :join :exdent
   Line1
   Line2
 heredoc

The :parse modifier turns a single value into
multiple values, e.g.,

 # :parse is same as :parse(\n)
 name = <<:parse
 value1
 value2
 <<

is the same as,

 name = value1
 name = value2

and

 name = <<:parse(/,\s+/)
 "Tom, Dick, and Harry", Fred and Wilma
 <<

is the same as,

 name = Tom, Dick, and Harry
 name = Fred and Wilma

The :parse modifier chomps only the last line by
default, so include '\n' to parse multiple lines.

 # liberal separators
 name = <<:parse([,\s\n]+)
 "Tom, Dick, and Harry" "Fred and Wilma"
 Martha George, 'Hillary and Bill'
 <<

is the same as,

 name = Tom, Dick, and Harry
 name = Fred and Wilma
 name = Martha
 name = George
 name = Hillary and Bill

=head2 Initialization Methods

=over 8

=item new()

=item new( 'filename' )

=item new( file => 'filename' )

=item new( fh => $filehandle )

=item new( string => $string )

Create an object with the new() method, e.g.,

  my $ini = Ini->new( 'inifile' );

If you pass any parameters, the init() object will be called.
If you pass only one parameter, it's assumed to be the file
name.  Otherwise, use the named parameters, C<file>, C<fh>,
or C<string> to pass a filename, filehandle (already open),
or string.  The string is assumed to look like the contents
of an ini file.

If you do not pass any parameters to new(), you can later
call init() with the same parameters described above.

=item init( 'filename' )

=item init( file => 'filename' )

=item init( fh => $filehandle )

=item init( string => $string )

 my $ini = Ini->new();
 $ini->init( 'filename' );

=back

=head2 Get Methods

=over 8

=item get( $section, $name )

=item get( $section, $name, $i )

=item get( $name )  (assumes $section=='')

Use get() to retrieve the value(s) for a given name.
If a name appears more than once in a section, the
values are pushed onto an array, and get() will return
this array of values.

 my @values = $ini->get( $section, $name );

Pass an array subscript as the third parameter to
return only one of the values in this array.

 my $value = $ini->get( $section, $name, 0 ); # get first one
 my $value = $ini->get( $section, $name, 1 ); # get second one
 my $value = $ini->get( $section, $name, -1 ); # get last one

If the ini file lists names at the beginning, before
any sections are given, the section name is assumed to
be the null string ('').  If you call get() with just
one parameter, it is assumed to be a name in this "null
section".  If you want to pass an array subscript, then
you must also pass a null string as the first parameter.

 my @values = $ini->get( $name );         # assumes $section==''
 my $value  = $ini->get( '', $name, 0 );  # get first occurrence
 my $value  = $ini->get( '', $name, -1 ); # get last occurrence

This "null section" concept allows for very simple
confuration files like:

 title = Hello World
 color: blue
 margin: 0

=item get_aref( $section, $name )

=item get_aref( $name ) (assumes $section=='')

Use get_aref() for a reference to the array of values.

 my $aref = $ini->get_aref( $section, $name );
 print join "\n", @$aref;

=item get_sections()

Use get_sections() to retrieve a list of the sections in the
ini file.  They are returned in the order they appear in the
file.

 my @sections = $ini->get_sections();

If there is a "null section", it will be the first in the
list.

=item get_names( $section )

Use get_names() to retrieve a list of the names in a given
section.  They are returned in the order they appear in the
section.  If a name appears twice in a section, it only
appears once in this list.

 my @names = $ini->get_names( $section );

=back

=head2 Add Methods

This module is a simple ini file reader, so the
add methods are used mainly internally.  See
Ini::Edit for methods that let you edit an ini
file.

=over 8

=item add( $section, $name, @values )

Use add() to add to the value(s) of an option.  If
the option already has values, the new values will
be added to the end (pushed onto the array).

 $ini->add( $section, $name, @values );

If the section does not already exist, it will be
created.

=item add_section( $section )

Use add_section(), if desired, to create a new
(empty) section.
Normally, you will never have to call this method;
new sections are added internally as needed.
If the section already exists, this method will do
nothing.  The method is mostly used internally, but
there is nothing wrong in calling it yourself.

 $ini->add_section( 'new_section' );

=back

=head1 SEE ALSO

Ini::Edit,
Ini::Expanded,
Ini::Quote,
Config::IniFiles,
Config:: ... (to infinity and beyond)

=head1 AUTHOR

Brad Baxter, E<lt>bmb@mail.libs.uga.eduE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2006 by Brad Baxter

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.7 or,
at your option, any later version of Perl 5 you may have available.


=cut
