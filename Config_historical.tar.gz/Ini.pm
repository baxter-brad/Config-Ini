#---------------------------------------------------------------------
package Ini;

use 5.008007;
use strict;
use warnings;

our @ISA = qw();

our $VERSION = '0.01';

our $keep_comments = 0;    # boolean, user may set to 1
our $heredoc_style = '{';  # for as_string() (vi})

## $ini = Ini->new( file=>$file, fh=>$fh, string=>$string )
# $ini->init( file=>$file, fh=>$fh, string=>$string )
## $ini->get( $section, $name, $i )
## $ini->get_aref( $section, $name )
# $ini->put( $section, $name, @values )
# $ini->add( $section, $name, @values )
# $ini->add_comments( $section, $name, @comments )
## $ini->get_comments( $section, $name, $i )
## $ini->get_sections()
## $ini->get_names( $section )
# $ini->add_section( $section )
# $ini->put_section_comments( $section, $comments )
## $ini->get_section_comments( $section )
# $ini->as_string()

use constant SECTIONS => 0;
use constant SHASH    => 1;
use constant NAMES  => 0;
use constant NHASH  => 1;
use constant SCMTS  => 2;
use constant VALS => 0;
use constant CMTS => 1;

# Object:   [
# SECTIONS:     [ 'section1', ],
# SHASH:        {
#                   section1 => [
#     NAMES:            [ 'name1', ],
#     NHASH:            {
#                           name1 => [
#         VALS:                 [ $value1, ],
#         CMTS:                 [ $comments, ],
#                           ],
#                       },
#     SCMTS:            $comments,
#                   ],
#               },
#           ],
  
#---------------------------------------------------------------------
## $ini = Ini->new( file=>$file, fh=>$fh, string=>$string )
sub new {
    my ( $class, %parms ) = @_;
    my $self  = [];
    bless $self, $class;
    $self->init( %parms ) if %parms;
    return $self;
}

#---------------------------------------------------------------------
## $ini->init( file=>$file, fh=>$fh, string=>$string )
sub init {
    my ( $self, %parms ) = @_;

    my $file   = $parms{'file'};
    my $fh     = $parms{'fh'};
    my $string = $parms{'string'};

    unless( $fh ) {
        if( $string ) {
            open $fh, '<', \$string
                or die "Can't open string: $!"; }
        elsif( $file ) {
            open $fh, '<', $file
                or die "Can't open $file: $!"; }
        else { die "Invalid parms" }
    }

    my $section = '';
    my $name = '';
    my $value;
    my $pending_comments = '';

    while( <$fh> ) {

        # comment or blank line
        if( /^\s*#/ or /^$/ ) {
            next unless $keep_comments;
            $pending_comments .= $_;
            next;
        }

        # [section]
        if( /^\[([^{}\]]+)\](\s*#.*\s*)?/ ) {
            $section = $1;
            my $comment = $2;
            $self->add_section( $1 );
            next unless $keep_comments;
            $pending_comments .= $comment if $comment;
            if( $pending_comments ) {
                $self->put_section_comments( $section, $pending_comments );
                $pending_comments = '';
            }
            next;
        }  # if

        # <<heredoc
        # Note: name = {xyz} is not seen as a heredoc
        elsif( /^\s*(.+?)\s*=\s*(<<|{)\s*([^}]*?)\s*$/ ) {
            $name = $1;
            $value = '';
            my $endtag = (
                $2 eq '<<' ? '<<' :
                $2 eq '{'  ? '}'  : die );
            my $heretag = $3;
            my $join  = ($heretag =~ s/join\s*//i ) ? 1 : '';
            my $chomp = ($heretag =~ s/chomp\s*//i) ? 1 : '';
            my $found;
            while( <$fh> ) {
                if( ( $heretag ne '' and
                    /^\s*(?:$endtag)*\s*\Q$heretag\E\s*$/ ) ||
                    ( $heretag eq '' and
                    /^\s*$endtag\s*$/ ) ) {
                    ++$found; last; }
                else { chomp $value if $join; }
                $value .= $_;
            }  # while
            die "Didn't find heredoc end tag ($heretag) " .
                "for $section:$name" unless $found;
            chomp $value if $chomp;
        }  # elsif

        # name = value
        elsif( /^\s*(.+?)\s*=\s*(.*)$/ ) {
            $name = $1;
            $value = $2;
        }

        # "bare word" (treated as boolean set to true(1))
        else {
            s/^\s+//g; s/\s+$//g;
            $name = $_;
            $value = 1;
        }

        $self->add( $section, $name, $value );
        next unless $keep_comments;
        if( $pending_comments ) {
            $self->add_comments( $section, $name, $pending_comments );
            $pending_comments = '';
        }

    }  # while

    if( $pending_comments and $keep_comments ) {
        warn "Warning: discarding comments at end of file:\n",
            $pending_comments;
    }

}  # end sub init

#---------------------------------------------------------------------
## $ini->get( $section, $name, $i )
sub get {
    my ( $self, $section, $name, $i ) = @_;
    return unless defined $section and defined $name;

    my $aref = $self->[SHASH]{ $section }[NHASH]{ $name }[VALS];
    return unless $aref;
    return @$aref if wantarray;
    return $aref->[ $i ] if defined $i;
    return "@$aref";
}

#---------------------------------------------------------------------
## $ini->get_aref( $section, $name )
sub get_aref {
    my ( $self, $section, $name ) = @_;
    return unless defined $section and defined $name;

    my $aref = $self->[SHASH]{ $section }[NHASH]{ $name }[VALS];
    return unless $aref;
    return $aref;
}

#---------------------------------------------------------------------
## $ini->put( $section, $name, @values )
sub put {
    my ( $self, $section, $name, @values ) = @_;
    return unless defined $section and defined $name;

    push @{$self->[SHASH]{ $section }[NAMES]}, $name
        unless exists $self->[SHASH]{ $section }[NHASH]{ $name };
    $self->[SHASH]{ $section }[NHASH]{ $name }[VALS] = [ @values ];
}

#---------------------------------------------------------------------
## $ini->add( $section, $name, @values )
sub add {
    my ( $self, $section, $name, @values ) = @_;
    return unless defined $section and defined $name;

    push @{$self->[SHASH]{ $section }[NAMES]}, $name
        unless exists $self->[SHASH]{ $section }[NHASH]{ $name };
    push @{$self->[SHASH]{ $section }[NHASH]{ $name }[VALS]}, @values;
}

#---------------------------------------------------------------------
## $ini->add_comments( $section, $name, @comments )
sub add_comments {
    my ( $self, $section, $name, @comments ) = @_;
    return unless
        defined $section and
        defined $name and
        @comments;

    push @{$self->[SHASH]{ $section }[NAMES]}, $name
        unless exists $self->[SHASH]{ $section }[NHASH]{ $name };
    push @{$self->[SHASH]{ $section }[NHASH]{ $name }[CMTS]}, @comments;
}

#---------------------------------------------------------------------
## $ini->get_comments( $section, $name, $i )
sub get_comments {
    my ( $self, $section, $name, $i ) = @_;
    return unless defined $section and defined $name;

    my $aref = $self->[SHASH]{ $section }[NHASH]{ $name }[CMTS];
    return unless $aref;
    return @$aref if wantarray;
    return $aref->[ $i ] if defined $i;
    return join '', @$aref;
}

#---------------------------------------------------------------------
## $ini->get_sections()
sub get_sections {
    my ( $self ) = @_;

    return unless defined $self->[SECTIONS];
    return @{$self->[SECTIONS]};
}

#---------------------------------------------------------------------
## $ini->get_names( $section )
sub get_names {
    my ( $self, $section ) = @_;
    return unless defined $section;

    return unless defined $self->[SHASH]{ $section }[NAMES];
    return @{$self->[SHASH]{ $section }[NAMES]};
}

#---------------------------------------------------------------------
## $ini->add_section( $section )
sub add_section {
    my ( $self, $section ) = @_;
    return unless defined $section;

    # only add it once
    unless( exists $self->[SHASH]{ $section } ) {
        push @{$self->[SECTIONS]}, $section;
        $self->[SHASH]{ $section } = [];
        return 1;
    }
    return '';
}

#---------------------------------------------------------------------
## $ini->put_section_comments( $section, $comments )
sub put_section_comments {
    my ( $self, $section, $comments ) = @_;
    return unless defined $section and $comments;

    $self->[SHASH]{ $section }[SCMTS] = $comments;
}

#---------------------------------------------------------------------
## $ini->get_section_comments( $section )
sub get_section_comments {
    my ( $self, $section ) = @_;
    return unless defined $section;

    $self->[SHASH]{ $section }[SCMTS];
}

#---------------------------------------------------------------------
## $ini->as_string()
sub as_string {
    my ( $self, $style ) = @_;
    $style = $heredoc_style unless $style;

    return unless $style eq '{' or $style eq '<<';  # (vi})
    my $end = $style eq '{' ? '}' : '<<';

    my $output = '';

    my @sections = $self->get_sections();
    foreach my $section ( @sections ) {

        $output .= $self->get_section_comments( $section )
            if $keep_comments;
        $output .= "[$section]\n";

        my @names = $self->get_names( $section );
        foreach my $name ( @names ) {

            my @values = $self->get( $section, $name );
            my $i = 0;
            foreach my $value ( @values ) {

                if( $keep_comments and
                    defined( my $comments =
                    $self->get_comments( $section, $name, $i++ ) ) ) {
                    $output .= $comments; }

                # need heredoc if value contains \n
                if( $value =~ /\n/ ) {

                    # need chomp if value doesn't end in \n
                    my ( $b, $e ) = $value =~ /\n$/ ?
                        ( '', '' ) : ( 'chomp', "\n" );

                    # need heretag if value contains heredoc marker
                    if( $value =~ /^\s*$end/m ) {
                        my $r = 1;
                        do { $r = sprintf "%002d", $r++; }
                            while $value =~ /^${end}_${r}_\s*/m;
                        $value = "$style${b}_${r}_\n$value$e${end}_${r}_"; }
                    else {
                        $value = "$style$b\n$value$e${end}"; }
                }

                $output .= "$name = $value\n";
            }
        }
    }
    return $output;
}

#---------------------------------------------------------------------
1;

__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

Ini - Perl extension for blah blah blah

=head1 SYNOPSIS

  use Ini;
  blah blah blah

=head1 DESCRIPTION

Stub documentation for Ini, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.


=head1 SEE ALSO

Mention other useful documentation such as the documentation of
related modules or operating system documentation (such as man pages
in UNIX), or any relevant external documentation such as RFCs or
standards.

If you have a mailing list set up for your module, mention it here.

If you have a web site set up for your module, mention it here.

=head1 AUTHOR

Brad Baxter, E<lt>bmb@mail.libs.uga.eduE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2006 by Brad Baxter

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.7 or,
at your option, any later version of Perl 5 you may have available.


=cut
