#---------------------------------------------------------------------
package Ini::Expanded;

use 5.008000;
use strict;
use warnings;
use Carp;

=head1 NAME

Config::Ini::Expanded - ini style configuration file reading/writing
with template expansion capabilities.

=head1 SYNOPSIS

 use Config::Ini::Expanded;

 my $ini = Config::Ini::Expanded->new( 'file.ini' );

 # traverse the values
 for my $section ( $ini->get_sections() ) {
     print "$section\n";

     for my $name ( $ini->get_names( $section ) {
         print "  $name\n";

         for my $value ( $ini->get( $section, $name ) ) {
             print "    $value\n";
         }
     }
 }

=head1 VERSION

VERSION = 0.01

=cut

# more POD follows the __END__

our $VERSION = '0.01';

our @ISA = qw( Config::Ini::Edit );
use Config::Ini::Edit;
use Config::Ini::Quote ':all';
use Text::ParseWords;
use JSON;
$JSON::Pretty  = 1;
$JSON::BareKey = 1;  # *accepts* bare keys
$JSON::KeySort = 1;

our $keep_comments = 0;     # boolean, user may set to 1
our $heredoc_style = '<<';  # for as_string()
our $interpolate   = 1;     # double-quote expansions
our $include_root  = '';    # for INCLUDE/FILE expansions
our $loop_limit = 10;
our $size_limit = 1_000_000;

use constant SECTIONS => 0;
use constant SHASH    => 1;
use constant ATTRS    => 2;
use constant VAR      => 3;
use constant NAMES  => 0;
use constant NHASH  => 1;
use constant SCMTS  => 2;
use constant VALS  => 0;
use constant CMTS  => 1;
use constant VATTR => 2;
# VATTR: {
#     quote     => [',"],
#     comment   => 'string',
#     herestyle => [{,{},<<,<<<<],
#     heretag   => 'string',
#     escape    => ':slash' and/or ':html',
#     indent    => indent value
#     json      => ':json',
# }

# object structure summary:
#           [
# SECTIONS:     [ 'section1', ],
# SHASH:        {
#                   section1 => [
#     NAMES:            [ 'name1', ],
#     NHASH:            {
#                           name1 => [
#         VALS:                 [ $value1, ],
#         CMTS:                 [ $comments, ],
#         VATTR:                [ $val_attrs, ],
#                           ],
#                       },
#     SCMTS:            [ $comments, $comment ],
#                   ],
#               },
# ATTRS:        { ... },
# VAR:          { ... },
#           ],

#---------------------------------------------------------------------
# inherited methods
## new()                                    see Config::Ini
## $ini->get_names( $section )              see Config::Ini
## $ini->get( $section, $name, $i )         see Config::Ini
## $ini->add( $section, $name, @values )    see Config::Ini
## $ini->set( $section, $name, $i, $value ) see Config::Ini
## $ini->put( $section, $name, @values )    see Config::Ini
## $ini->delete_section( $section )         see Config::Ini
## $ini->delete_name( $section, $name )     see Config::Ini
## $ini->_attr( $attribute, $value )        see Config::Ini
## $ini->_autovivify( $section, $name )     see Config::Ini
## $ini->get_sections( $all )               see Config::Ini::Edit
## $ini->get_comments( $section, $name, $i )               ::Edit
## $ini->set_comments( $section, $name, $i, @comments )    ::Edit
## $ini->get_comment( $section, $name, $i )                ::Edit
## $ini->set_comment( $section, $name, $i, @comments )     ::Edit
## $ini->get_section_comments( $section )                  ::Edit
## $ini->set_section_comments( $section, @comments )       ::Edit
## $ini->get_section_comment( $section )                   ::Edit
## $ini->set_section_comment( $section, @comments )        ::Edit
## $ini->vattr( $section, $name, $i, $attribute, $value )  ::Edit

#---------------------------------------------------------------------
## $ini->init( $file )            or
## $ini->init( file   =>$file   ) or
## $ini->init( fh     =>$fh     ) or
## $ini->init( string =>$string )
sub init {
    my ( $self, @parms ) = @_;

    my ( $file, $fh, $string, $included );
    my ( $keep, $style );
    if( @parms == 1 ) {
        $file   = $parms[0]; }
    else {
        my %parms = @parms;
        $file     = $parms{'file'};
        $fh       = $parms{'fh'};
        $string   = $parms{'string'};
        $included = $parms{'included'};

        for( qw(
            keep_comments heredoc_style interpolate
            include_root  loop_limit    size_limit
            ) ) {
            no strict 'refs';
            $self->_attr( $_ => $parms{ $_ } || $$_ );
        }
    }
    $self->_attr( file => $file ) if $file;
    my $keep_comments = $self->_attr( 'keep_comments' );
    my $interpolate   = $self->_attr( 'interpolate' );

    unless( $fh ) {
        if( $string ) {
            open $fh, '<', \$string
                or croak "Can't open string: $!"; }
        elsif( $file ) {
            open $fh, '<', $file
                or croak "Can't open $file: $!"; }
        else { croak "Invalid parms" }
    }

    my $section = '';
    my $name = '';
    my $value;
    my %vattr;
    my $comment;
    my $pending_comments = '';
    my %i;

    local *_;
    while( <$fh> ) {
        my $parse  = '';
        my $escape = '';
        my $json   = '';
        my $heredoc = '';
        my $q = '';

        # comment or blank line
        if( /^\s*[#;]/ or /^\s*$/ ) {
            next unless $keep_comments;
            $pending_comments .= $_;
            next;
        }

        # [section]
        if( /^\[([^\]]+)\](\s*[#;].*\s*)?/ ) {
            $section = $1;
            my $comment = $2;
            $self->_autovivify( $section );
            next unless $keep_comments;
            if( $pending_comments ) {
                $self->set_section_comments( $section, $pending_comments );
                $pending_comments = '';
            }
            $self->set_section_comment( $section, $comment ) if $comment;
            next;
        }  # if

        # <<heredoc
        # Note: name = {xyz} <<xyz>> must not be seen as a heredoc
        elsif( /^\s*(.+?)\s*[=:]\s*(<<|{)\s*([^}>]*?)\s*$/ ) {
            $name       = $1;
            my $style   = $2;
            my $heretag = $3;

            $value = '';

            my $endtag = $style eq '{' ? '}' : '<<';

            ( $q, $heretag, $comment ) = ( $1, $2, $3 )
                if $heretag =~ /^(['"])(.*)\1\s*([#;].*)?/;
            my $indent = ($heretag =~ s/\s*:indent\s*//i ) ? 1 : '';
            my $join   = ($heretag =~ s/\s*:join\s*//i )   ? 1 : '';
            my $chomp  = ($heretag =~ s/\s*:chomp\s*//i)   ? 1 : '';
            $json   = ($heretag =~ s/\s*(:json)\s*//i)  ? $1 : '';
            $escape .= ($heretag =~ s/\s*(:html)\s*//i)  ? $1 : '';
            $escape .= ($heretag =~ s/\s*(:slash)\s*//i) ? $1 : '';
            $parse = $1   if $heretag =~ s/\s*:parse\s*\(\s*(.*?)\s*\)\s*//;
            $parse = '\n' if $heretag =~ s/\s*:parse\s*//;
            my $extra = '';  # strip unrecognized (future?) modifiers
            $extra .= $1 while $heretag =~ s/\s*(:\w+)\s*//;

            my $found_end;
            while( <$fh> ) {
                if( $heretag eq '' ) {
                    if( /^\s*$endtag\s*$/ ) {
                        $style .= $endtag;
                        ++$found_end;
                    }
                }
                else {
                    if( ( /^\s*\Q$heretag\E\s*$/ ||
                        /^\s*$q\Q$heretag\E$q\s*$/ ) ) {
                        ++$found_end;
                    }
                    elsif( ( /^\s*$endtag\s*\Q$heretag\E\s*$/ ||
                        /^\s*$endtag\s*$q\Q$heretag\E$q\s*$/ ) ) {
                        $style .= $endtag;
                        ++$found_end;
                    }
                }

                last         if $found_end;
                chomp $value if $join;
                if( $indent ) {
                    if( s/^(\s+)// ) {
                        $indent = $1 if $indent !~ /^\s+$/;
                    }
                }
                $value .= $_;

            }  # while

            croak "Didn't find heredoc end tag ($heretag) " .
                "for $section:$name" unless $found_end;

            # ':parse' enables ':chomp', too
            chomp $value if $chomp or $parse ne '';

            # value attributes (n/a if value parsed)
            if( $parse eq '' ) {
                $vattr{'quote'  }   = $q       if $q;
                $vattr{'heretag'}   = $heretag if $heretag;
                $vattr{'herestyle'} = $style   if $style;
                $vattr{'json'   }   = $json    if $json;
                $vattr{'escape' }   = $escape  if $escape;
                $vattr{'indent' }   = $indent  if $indent;
                $vattr{'extra'  }   = $extra   if $extra;
            }

            $heredoc = 1;

        }  # elsif (heredoc)

        # name = value
        elsif( /^\s*(.+?)\s*[=:]\s*(.*)$/ ) {
            $name = $1;
            $value = $2;
        }

        # {INCLUDE:file:sections}
        elsif( /^\s*{INCLUDE:([^:{}]+)(?::([^:{}]+))*}/ ) {
            my ( $file, $sections ) = ( $1, $2 );
            $file = $self->_attr( 'include_root' ) . $file;
            next if $included->{ $file }++;
            my $ini = Config::Ini::Expanded->new(
                file => $file, included => $included );
            my @sections = $sections     ?
                split(/[, ]+/,$sections) :
                $ini->get_sections();
            foreach my $section ( @sections ) {
                $self->add_section( $section );
                foreach my $name ( $ini->get_names( $section ) ) {
                    $self->add( $section, $name, 
                        $ini->get( $section, $name ) );
                }
            }
            next;
        }

        # "bare word" (treated as boolean set to true(1))
        else {
            s/^\s+//g; s/\s+$//g;
            $name = $_;
            $value = 1;
        }

        my $quote = sub {
            my( $q, $v, $e ) = @_;
            if( $q eq '' or $q eq "'" ) {
                return parse_single_quoted( "$q$v$q", $q ); }
            else {  # assume double quote-like
                $v = parse_double_quoted( "$q$v$q", $q, $e );
                return $v unless $interpolate;
                return $self->interpolate( $v );
            }
        };

        if( $heredoc ) {
            if( $q eq '"' ) {
                $value = parse_double_quoted( $value, '', $escape );
                $value = $self->interpolate( $value ) if $interpolate;
            }
        }
        elsif( $value =~ /^(['"])(.*)\1(\s*[#;].*)?/sm ) {
            $comment = $3 if $3 and $keep_comments;
            $vattr{'quote'} = $1;
            $value = $quote->( $1, $2, $escape );
        }

        $vattr{'comment'} = $comment if $comment;
        $comment = '';

        if( $parse ne '' ) {
            $parse = $quote->( $1, $2 )
                if $parse =~ /^(['"\/])(.*)\1$/;
            $self->add( $section, $name,
                map { (defined $_) ? $_ : '' }
                parse_line( $parse, 0, $value ) );
        }
        else {
            $value = jsonToObj $value if $json;
            $self->add( $section, $name, $value );
            $self->vattr( $section, $name, $i{ $section }{ $name },
                %vattr ) if %vattr;
        }

        %vattr = ();

        if( $pending_comments ) {
            $self->set_comments( $section, $name, $i{ $section }{ $name }, $pending_comments );
            $pending_comments = '';
        }

        $i{ $section }{ $name }++;

    }  # while

    if( $pending_comments ) {
        $self->set_section_comments( '__END__', $pending_comments );
    }

}  # end sub init

#---------------------------------------------------------------------
## $ini->interpolate( $value )
sub interpolate {
    my( $self, $val ) = @_;
    for ( $val ) {
        no warnings 'uninitialized';  # (vi{{{{{)
        s<{VAR:([^:}\s]+)}>
            {$self->get_var($1)}ge;
        s<{INI:([^:}\s]+):([^:}\s]+)(?::([^:}\s]+))?}>
            {$self->get($1,$2,$3)}ge;
        s<{FILE:([^:}\s]+)}>
            {$self->readfile($1)}ge;
    }
    return $val;
}

#---------------------------------------------------------------------
## $ini->get_var( $var )
sub get_var {
    my ( $self, $var ) = @_;
    return unless defined $self->[VAR];
    return unless defined $self->[VAR]{$var};
    return $self->[VAR]{$var};
}

#---------------------------------------------------------------------
## $ini->set_var( $var, $value, ... )
sub set_var {
    my ( $self, @vars ) = @_;
    return unless @vars;
    if( @vars == 1 ) {
        if( not defined $vars[0] ) {
            delete $self->[VAR];
        }
        elsif( ref $vars[0] eq 'HASH' ) {
            my $href = $vars[0];
            $self->[VAR]{ $_ } = $href->{ $_ } for keys %$href;
        }
        else {
            croak "Bad call to set_var()";
        }
        return;
    }
    $self->[VAR]{shift @vars} = shift @vars while @vars;
}

#---------------------------------------------------------------------
## $ini->get_expanded( $section, $name, $i )
sub get_expanded {
    my ( $self, $section, $name, $i ) = @_;
    my @ret = $self->get( $section, $name, $i );
    return unless @ret;
    for( @ret ) {
        $_ = $self->expand( $_, $section, $name ) };
    return @ret if wantarray;
    return "@ret";
}

#---------------------------------------------------------------------
## $ini->expand( $value, $section, $name )
# $value is changed
sub expand {
    my ( $self, $value, $section, $name ) = @_;
    my $changes;
    my $loops;
    while( 1 ) {
        no warnings 'uninitialized';  #vi{{{{{
        $changes += $value =~ s<{VAR:([^:}\s]+)}>
            {$self->get_var($1)}ge;
        $changes += $value =~
            s<{INI:([^:}\s]+):([^:}\s]+)(?::([^:}\s]+))?}>
            {$self->get($1,$2,$3)}ge;
        $changes += $value =~ s<{FILE:([^:}\s]+)}>
            {$self->readfile($1)}ge;
        last unless $changes;
        $changes = 0;
        if( ++$loops > $loop_limit or
            length $value > $size_limit ) {
            my $msg = "Loop alert at [$section], $name:\n" .
            ((length($value) > 44) ?
            substr( $value, 0, 44 ).'...('.length($value).')...' :
            $value);
            croak $msg;
        }
    }  # while
    return $value;
}

#---------------------------------------------------------------------
## $ini->readfile( $file )
sub readfile {
    my ( $self, $file ) = @_;
    $file = $self->include_root() . $file;
    open my $fh, $file or croak "Can't open $file: $!";
    local $/;
    return <$fh>;
}

#---------------------------------------------------------------------
## AUTOLOAD() (wrapper for _attr())
## file( $filename )
## keep_comments( 0 )
## heredoc_style( '<<' )
## interpolate( 1 )
## include_root( $include_root )
## loop_limit( 10 )
## size_limit( 1_000_000 )
our $AUTOLOAD;
sub AUTOLOAD {
    my $attribute = $AUTOLOAD;
    $attribute =~ s/.*:://;
    return unless $attribute =~ /^(?:
        file | keep_comments | heredoc_style | interpolate
        include_root | loop_limit | size_limit
        )$/x;
    my $self = shift;
    $self->_attr( $attribute, @_ );
}

#---------------------------------------------------------------------
1;

__END__
=head1 DESCRIPTION

This is an ini file processor with template expansion
capabilities.

This class inherits methods from Config::Ini::Edit (and
Config::Ini).

=head2 Terminology

 # comment
 [section]
 name = value

In particular 'name' is the term used to refer to the
named options within the sections.

=head2 Initialization Methods

=over 8

=item new()

=item new( 'filename' )

=item new( file => 'filename' )

=item new( fh => $filehandle )

=item new( string => $string )

Create an object with the new() method, e.g.,

  my $ini = Ini::Expanded->new( 'inifile' );

If you pass any parameters, the init() object will be called.
If you pass only one parameter, it's assumed to be the file
name.  Otherwise, use the named parameters, C<file>, C<fh>,
or C<string> to pass a filename, filehandle (already open),
or string.  The string is assumed to look like the contents
of an ini file.

If you do not pass any parameters to new(), you can later
call init() with the same parameters described above.

=item init( 'filename' )

=item init( file => 'filename' )

=item init( fh => $filehandle )

=item init( string => $string )

 my $ini = Ini::Expanded->new();
 $ini->init( 'filename' );

=back

=head2 Get Methods

=over 8

=item get( $section, $name )

=item get( $section, $name, $i )

Use get() to retrieve the value(s) for a given name.
If a name appears more than once in a section, the
values are pushed onto an array, and get() will return
this array of values.

 my @values = $ini->get( $section, $name );

Pass an array subscript as the third parameter to
return only one of the values in this array.

 my $value = $ini->get( $section, $name, 0 ); # get first one
 my $value = $ini->get( $section, $name, 1 ); # get second one
 my $value = $ini->get( $section, $name, -1 ); # get last one

=item get_aref( $section, $name )

Use get_aref() for a reference to the array of values.

 my $aref = $ini->get_aref( $section, $name );
 print join "\n", @$aref;

=item get_sections()

Use get_sections() to retrieve a list of the sections in the
ini file.  They are returned in the order they appear in the
file.

 my @sections = $ini->get_sections();

=item get_names( $section )

Use get_names() to retrieve a list of the names in a given
section.  They are returned in the order they appear in the
section.  If a name appears twice in a section, it only
appears once in this list.

 my @names = $ini->get_names( $section );

=back

=head2 Put/Add Methods

=over 8

=item put( $section, $name, @values )

Use put() to set the value(s) of an option.  If the
option already has values, they will be discarded.
See also add() below.

 $ini->put( $section, $name, @values );

If the section does not already exist, it will be
created.

=item add( $section, $name, @values )

Use add() to add to the value(s) of an option.  If
the option already has values, the new values will
be added to the end (pushed onto the array).

 $ini->add( $section, $name, @values );

If the section does not already exist, it will be
created.

=item add_section( $section )

Use add_section() if desired, to create a new (empty) section.
Normally, you will never have to call this method;
new sections are added internally as needed.
If the section already exists, this method will do
nothing.  The method is mostly used internally, but
there is nothing wrong in calling it yourself.

 $ini->add_section( 'new_section' );

=back

=head2 Comments Methods

An ini file may contain comments.  Normally, when your
program reads an ini file, it doesn't care about comments.
But if you want to edit an ini file using the Ini::Expanded
module, you will want to keep the comments.

=over 8

=item $Ini::Expanded::keep_comments

Set $Ini::Expanded::keep_comments to 1 if you want the Ini::Expanded object
to retain the comments that are in the file.  The default
is 0--no comments are kept.  This applies to new(), init(),
and as_string(), i.e., new() and init() will load the
comments into the object, and as_string() will output these
comments if $Ini::Expanded::keep_comments is true.

=item get_comments( $section, $name )

=item get_comments( $section, $name, $i )

Use get_comments() to return the comments for a given
name.  Since names may be repeated (forming an array
of values), so might there be an array of comments.

 my @comments = get_comments( $section, $name );

Pass an array index as the third parameter to get just
one of the comments in this array

 my $comments = get_comments( $section, $name, 0 );

=item set_comments( $section, $name, $i, @comments )

Use set_comments() to specify comments for a given
occurrence of a name.

  $ini->set_comments( $section, $name, 0, 'Hello World' );

In an ini file, comments must begin with '#' or ';' and end
with a newline.  If your comments don't, '# ' and "\n" will
be added.

=item put_comments( $section, $name, @comments )

Use put_comments() so set all the comments for a given
name.  Use this in conjuction with put(), for example,
to set all the values and all the comments together.

 @values = ( 'Tom', 'Dick', 'Harry' );   
 @comments = ( 'Tom Robbins', 'Dick Van Dyke', 'Harry Reasoner' );   
 $ini->put_comments( $section, $name, @comments );
 $ini->put( $section, $name, @values );

=item get_section_comments( $section )

Use get_section_comments() to do just that.

 my $comments = $ini->get_section_comments( $section );

=item put_section_comments( $section, $comments )

Ditto.

 $ini->put_section_comments( $section, $comments );

=back

=head2 Recreating the Ini File Structure

=over 8

=item as_string()

Use as_string() to dump the Ini::Expanded object in an ini file
format.  If $Ini::Expanded::keep_comments is true, the comments
will be included.

 print INIFILE $ini->as_string();

=back

=head1 SEE ALSO

Ini,
Ini::Expanded,
Config::IniFiles,
Config:: ... (to infinity and beyond)

=head1 AUTHOR

Brad Baxter, E<lt>bmb@mail.libs.uga.eduE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2006 by Brad Baxter

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.7 or,
at your option, any later version of Perl 5 you may have available.


=cut
