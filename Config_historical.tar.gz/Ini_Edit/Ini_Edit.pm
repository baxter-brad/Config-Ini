#---------------------------------------------------------------------
package Ini;

use 5.008000;
use strict;
use warnings;
use Carp;

=head1 NAME

Ini - ini-style configuration file processing

=head1 VERSION

This document refers to version 0.01 of Ini, released Jan 10, 2006.

=head1 SYNOPSIS

 use Ini;

 my $ini = Ini->new( 'file.ini' );

 # traverse the values
 for my $section ( $ini->get_sections() ) {
     print "$section\n";

     for my $name ( $ini->get_names( $section ) {
         print "  $name\n";

         for my $value ( $ini->get( $section, $name ) ) {
             print "    $value\n";
         }
     }
 }

=cut

# more POD follows the __END__

our @ISA = qw();

our $VERSION = '0.01';

our $keep_comments = 0;    # boolean, user may set to 1
our $heredoc_style = '{';  # for as_string() (vi})

# methods summary:
# $ini = Ini->new( file=>$file, fh=>$fh, string=>$string )
# $ini->init( file=>$file, fh=>$fh, string=>$string )
# $ini->get( $section, $name, $i )
# $ini->get_aref( $section, $name )
# $ini->put( $section, $name, @values )
# $ini->add( $section, $name, @values )
# $ini->set_comments( $section, $name, @comments )
# $ini->put_comments( $section, $name, @comments )
# $ini->get_comments( $section, $name, $i )
# $ini->get_sections()
# $ini->get_names( $section )
# $ini->add_section( $section )
# $ini->put_section_comments( $section, $comments )
# $ini->get_section_comments( $section )
# $ini->as_string()

use constant SECTIONS => 0;
use constant SHASH    => 1;
use constant NAMES  => 0;
use constant NHASH  => 1;
use constant SCMTS  => 2;
use constant VALS => 0;
use constant CMTS => 1;

# object structure summary:
#           [
# SECTIONS:     [ 'section1', ],
# SHASH:        {
#                   section1 => [
#     NAMES:            [ 'name1', ],
#     NHASH:            {
#                           name1 => [
#         VALS:                 [ $value1, ],
#         CMTS:                 [ $comments, ],
#                           ],
#                       },
#     SCMTS:            $comments,
#                   ],
#               },
#           ],
  
#---------------------------------------------------------------------
## $ini = Ini->new( $file )             or
## $ini = Ini->new( file   => $file   ) or
## $ini = Ini->new( fh     => $fh     ) or
## $ini = Ini->new( string => $string )
sub new {
    my ( $class, @parms ) = @_;
    my $self  = [];
    bless $self, $class;
    $self->init( @parms ) if @parms;
    return $self;
}

#---------------------------------------------------------------------
## $ini->init( $file )            or
## $ini->init( file   =>$file   ) or
## $ini->init( fh     =>$fh     ) or
## $ini->init( string =>$string )
sub init {
    my ( $self, @parms ) = @_;

    my ( $file, $fh, $string );
    if( @parms == 1 ) {
        $file   = $parms[0]; }
    else {
        my %parms = @parms;
        $file   = $parms{'file'};
        $fh     = $parms{'fh'};
        $string = $parms{'string'}; }

    unless( $fh ) {
        if( $string ) {
            open $fh, '<', \$string
                or croak "Can't open string: $!"; }
        elsif( $file ) {
            open $fh, '<', $file
                or croak "Can't open $file: $!"; }
        else { croak "Invalid parms" }
    }

    my $section = '';
    my $name = '';
    my $value;
    my $pending_comments = '';
    my %i;

    while( <$fh> ) {

        # comment or blank line
        if( /^\s*#/ or /^\s*$/ ) {
            next unless $keep_comments;
            $pending_comments .= $_;
            next;
        }

        # [section]
        if( /^\[([^{}\]]+)\](\s*#.*\s*)?/ ) {
            $section = $1;
            my $comment = $2;
            $self->add_section( $1 );
            next unless $keep_comments;
            $pending_comments .= $comment if $comment;
            if( $pending_comments ) {
                $self->put_section_comments( $section, $pending_comments );
                $pending_comments = '';
            }
            next;
        }  # if

        # <<heredoc
        # Note: name = {xyz} is not seen as a heredoc
        elsif( /^\s*(.+?)\s*=\s*(<<|{)\s*([^}]*?)\s*$/ ) {
            $name = $1;
            $value = '';
            my $endtag = (
                $2 eq '<<' ? '<<' :
                $2 eq '{'  ? '}'  : die );
            my $heretag = $3;
            my $join  = ($heretag =~ s/join\s*//i ) ? 1 : '';
            my $chomp = ($heretag =~ s/chomp\s*//i) ? 1 : '';
            my $found;
            while( <$fh> ) {
                if( ( $heretag ne '' and
                    /^\s*(?:$endtag)*\s*\Q$heretag\E\s*$/ ) ||
                    ( $heretag eq '' and
                    /^\s*$endtag\s*$/ ) ) {
                    ++$found; last; }
                else { chomp $value if $join; }
                $value .= $_;
            }  # while
            die "Didn't find heredoc end tag ($heretag) " .
                "for $section:$name" unless $found;
            chomp $value if $chomp;
        }  # elsif

        # name = value
        elsif( /^\s*(.+?)\s*=\s*(.*)$/ ) {
            $name = $1;
            $value = $2;
        }

        # "bare word" (treated as boolean set to true(1))
        else {
            s/^\s+//g; s/\s+$//g;
            $name = $_;
            $value = 1;
        }

        $self->add( $section, $name, $value );
        next unless $keep_comments;

        if( $pending_comments ) {
            $self->set_comments( $section, $name,
                $i{ $section }{ $name }++, $pending_comments );
            $pending_comments = '';
        }
        else {
            $i{ $section }{ $name }++;
        }

    }  # while

    if( $pending_comments and $keep_comments ) {
        carp "Warning: discarding comments at end of file:\n",
            $pending_comments;
    }

}  # end sub init

#---------------------------------------------------------------------
## $ini->get( $section, $name, $i )
sub get {
    my ( $self, $section, $name, $i ) = @_;
    return unless defined $section and defined $name;

    my $aref = $self->[SHASH]{ $section }[NHASH]{ $name }[VALS];
    return unless $aref;
    return @$aref if wantarray;
    return $aref->[ $i ] if defined $i;
    return "@$aref";
}

#---------------------------------------------------------------------
## $ini->get_aref( $section, $name )
sub get_aref {
    my ( $self, $section, $name ) = @_;
    return unless defined $section and defined $name;

    my $aref = $self->[SHASH]{ $section }[NHASH]{ $name }[VALS];
    return unless $aref;
    return $aref;
}

#---------------------------------------------------------------------
## $ini->put( $section, $name, @values )
sub put {
    my ( $self, $section, $name, @values ) = @_;
    return unless defined $section and defined $name;

    $self->add_section( $section ) unless $self->[SHASH]{ $section };

    push @{$self->[SHASH]{ $section }[NAMES]}, $name
        unless $self->[SHASH]{ $section }[NHASH]{ $name };
    $self->[SHASH]{ $section }[NHASH]{ $name }[VALS] = [ @values ];
}

#---------------------------------------------------------------------
## $ini->add( $section, $name, @values )
sub add {
    my ( $self, $section, $name, @values ) = @_;
    return unless defined $section and defined $name;

    $self->add_section( $section ) unless $self->[SHASH]{ $section };

    push @{$self->[SHASH]{ $section }[NAMES]}, $name
        unless $self->[SHASH]{ $section }[NHASH]{ $name };
    push @{$self->[SHASH]{ $section }[NHASH]{ $name }[VALS]}, @values;
}

#---------------------------------------------------------------------
## $ini->set_comments( $section, $name, $i, @comments )
sub set_comments {
    my ( $self, $section, $name, $i, @comments ) = @_;
    return unless
        defined $section and
        defined $name and
        @comments;
    $i = 0 unless defined $i;

    for( @comments ) {
        s/^(?!\s*[#\n])/# /mg;
        s/$/\n/ unless /\n$/;
    }

    $self->add_section( $section ) unless $self->[SHASH]{ $section };

    push @{$self->[SHASH]{ $section }[NAMES]}, $name
        unless $self->[SHASH]{ $section }[NHASH]{ $name };
    $self->[SHASH]{ $section }[NHASH]{ $name }[CMTS][ $i ] =
        join '', @comments;
}

#---------------------------------------------------------------------
## $ini->put_comments( $section, $name, @comments )
sub put_comments {
    my ( $self, $section, $name, @comments ) = @_;
    return unless
        defined $section and
        defined $name and
        @comments;

    $self->add_section( $section ) unless $self->[SHASH]{ $section };

    push @{$self->[SHASH]{ $section }[NAMES]}, $name
        unless $self->[SHASH]{ $section }[NHASH]{ $name };
    $self->[SHASH]{ $section }[NHASH]{ $name }[CMTS] =
        [ map { s/^(?!\s*[#\n])/# /mg; s/$/\n/ unless /\n$/; $_ }
        @comments ];
}

#---------------------------------------------------------------------
## $ini->get_comments( $section, $name, $i )
sub get_comments {
    my ( $self, $section, $name, $i ) = @_;
    return unless defined $section and defined $name;

    my $aref = $self->[SHASH]{ $section }[NHASH]{ $name }[CMTS];
    return unless $aref;
    return @$aref if wantarray;
    return $aref->[ $i ] if defined $i;
    no warnings 'uninitialized';
    return join '', @$aref;
}

#---------------------------------------------------------------------
## $ini->get_sections()
sub get_sections {
    my ( $self ) = @_;

    return unless defined $self->[SECTIONS];
    return @{$self->[SECTIONS]};
}

#---------------------------------------------------------------------
## $ini->get_names( $section )
sub get_names {
    my ( $self, $section ) = @_;
    return unless defined $section;

    return unless defined $self->[SHASH]{ $section }[NAMES];
    return @{$self->[SHASH]{ $section }[NAMES]};
}

#---------------------------------------------------------------------
## $ini->add_section( $section )
sub add_section {
    my ( $self, $section ) = @_;
    return unless defined $section;

    # only add it once
    unless( $self->[SHASH]{ $section } ) {
        push @{$self->[SECTIONS]}, $section;
        $self->[SHASH]{ $section } = [];
        return 1;
    }
    return '';
}

#---------------------------------------------------------------------
## $ini->put_section_comments( $section, $comments )
sub put_section_comments {
    my ( $self, $section, $comments ) = @_;
    return unless defined $section and $comments;
    for( $comments ) {
        s/^(?!\s*[#\n])/# /mg;
        s/$/\n/ unless /\n$/;
    }

    $self->[SHASH]{ $section }[SCMTS] = $comments;
}

#---------------------------------------------------------------------
## $ini->get_section_comments( $section )
sub get_section_comments {
    my ( $self, $section ) = @_;
    return unless defined $section;

    $self->[SHASH]{ $section }[SCMTS];
}

#---------------------------------------------------------------------
## $ini->as_string()
sub as_string {
    my ( $self, $style ) = @_;
    $style = $heredoc_style unless $style;

    return unless $style eq '{' or $style eq '<<';  # (vi})
    my $end = $style eq '{' ? '}' : '<<';

    my $output = '';

    my @sections = $self->get_sections();
    foreach my $section ( @sections ) {

        if( $keep_comments and
            defined( my $comments =
            $self->get_section_comments( $section ) ) ) {
            $output .= $comments; }

        $output .= "[$section]\n";

        my @names = $self->get_names( $section );
        foreach my $name ( @names ) {

            my @values = $self->get( $section, $name );
            my $i = 0;
            foreach my $value ( @values ) {

                if( $keep_comments and
                    defined( my $comments =
                    $self->get_comments( $section, $name, $i++ ) ) ) {
                    $output .= $comments; }

                # need heredoc if value contains \n
                if( $value =~ /\n/ ) {

                    # need chomp if value doesn't end in \n
                    my ( $b, $e ) = $value =~ /\n$/ ?
                        ( '', '' ) : ( 'chomp', "\n" );

                    # need heretag if value contains heredoc marker
                    if( $value =~ /^\s*$end/m ) {
                        my $r = 1;
                        do { $r = sprintf "%002d", $r++; }
                            while $value =~ /^${end}_${r}_\s*/m;
                        $value = "$style${b}_${r}_\n$value$e${end}_${r}_"; }
                    else {
                        $value = "$style$b\n$value$e${end}"; }
                }

                $output .= "$name = $value\n";
            }
        }
    }
    return $output;
}

#---------------------------------------------------------------------
1;

__END__
=head1 DESCRIPTION

This is yet another ini-file processor.  The motivation
is simply that I have more control over the features I
add.

=head2 Terminology

 # comment
 [section]
 name = value

In particular 'name' is the term used to refer to the
named options within the sections.

=head2 Initialization Methods

=over 8

=item new()

=item new( 'filename' )

=item new( file => 'filename' )

=item new( fh => $filehandle )

=item new( string => $string )

Create an object with the new() method, e.g.,

  my $ini = Ini->new( 'inifile' );

If you pass any parameters, the init() object will be called.
If you pass only one parameter, it's assumed to be the file
name.  Otherwise, use the named parameters, C<file>, C<fh>,
or C<string> to pass a filename, filehandle (already open),
or string.  The string is assumed to look like the contents
of an ini file.

If you do not pass any parameters to new(), you can later
call init() with the same parameters described above.

=item init( 'filename' )

=item init( file => 'filename' )

=item init( fh => $filehandle )

=item init( string => $string )

 my $ini = Ini->new();
 $ini->init( 'filename' );

=back

=head2 Get Methods

=over 8

=item get( $section, $name )

=item get( $section, $name, $i )

Use get() to retrieve the value(s) for a given name.
If a name appears more than once in a section, the
values are pushed onto an array, and get() will return
this array of values.

 my @values = $ini->get( $section, $name );

Pass an array subscript as the third parameter to
return only one of the values in this array.

 my $value = $ini->get( $section, $name, 0 ); # get first one
 my $value = $ini->get( $section, $name, 1 ); # get second one
 my $value = $ini->get( $section, $name, -1 ); # get last one

=item get_aref( $section, $name )

Use get_aref() for a reference to the array of values.

 my $aref = $ini->get_aref( $section, $name );
 print join "\n", @$aref;

=item get_sections()

Use get_sections() to retrieve a list of the sections in the
ini file.  They are returned in the order they appear in the
file.

 my @sections = $ini->get_sections();

=item get_names( $section )

Use get_names() to retrieve a list of the names in a given
section.  They are returned in the order they appear in the
section.  If a name appears twice in a section, it only
appears once in this list.

 my @names = $ini->get_names( $section );

=back

=head2 Put/Add Methods

=over 8

=item put( $section, $name, @values )

Use put() to set the value(s) of an option.  If the
option already has values, they will be discarded.
See also add() below.

 $ini->put( $section, $name, @values );

If the section does not already exist, it will be
created.

=item add( $section, $name, @values )

Use add() to add to the value(s) of an option.  If
the option already has values, the new values will
be added to the end (pushed onto the array).

 $ini->add( $section, $name, @values );

If the section does not already exist, it will be
created.

=item add_section( $section )

Use add_section() if desired, to create a new (empty) section.
Normally, you will never have to call this method;
new sections are added internally as needed.
If the section already exists, this method will do
nothing.  The method is mostly used internally, but
there is nothing wrong in calling it yourself.

 $ini->add_section( 'new_section' );

=back

=head2 Comments Methods

An ini file may contain comments.  Normally, when your
program reads an ini file, it doesn't care about comments.
But if you want to edit an ini file using the Ini module,
you will want to keep the comments.

=over 8

=item $Ini::keep_comments

Set $Ini::keep_comments to 1 if you want the Ini object
to retain the comments that are in the file.  The default
is 0--no comments are kept.  This applies to new(), init(),
and as_string(), i.e., new() and init() will load the
comments into the object, and as_string() will output these
comments if $Ini::keep_comments is true.

=item get_comments( $section, $name )

=item get_comments( $section, $name, $i )

Use get_comments() to return the comments for a given
name.  Since names may be repeated (forming an array
of values), so might there be an array of comments.

 my @comments = get_comments( $section, $name );

Pass an array index as the third parameter to get just
one of the comments in this array

 my $comments = get_comments( $section, $name, 0 );

=item set_comments( $section, $name, $i, @comments )

Use set_comments() to specify comments for a given
occurrence of a name.

  $ini->set_comments( $section, $name, 0, 'Hello World' );

In an ini file, comments must begin with '#' and end
with a newline.  If your comments don't, these will
be added.

=item put_comments( $section, $name, @comments )

Use put_comments() so set all the comments for a given
name.  Use this in conjuction with put(), for example,
to set all the values and all the comments together.

 @values = ( 'Tom', 'Dick', 'Harry' );   
 @comments = ( 'Tom Robbins', 'Dick Van Dyke', 'Harry Reasoner' );   
 $ini->put_comments( $section, $name, @comments );
 $ini->put( $section, $name, @values );

=item get_section_comments( $section )

Use get_section_comments() to do just that.

 my $comments = $ini->get_section_comments( $section );

=item put_section_comments( $section, $comments )

Ditto.

 $ini->put_section_comments( $section, $comments );

=back

=head2 Recreating the Ini File Structure

=over 8

=item as_string()

Use as_string() to dump the Ini object in an ini file
format.  If $Ini::keep_comments is true, the comments
will be included.

 print INIFILE $ini->as_string();

=back

=head1 SEE ALSO

Config::IniFiles:

http://search.cpan.org/~gcarls/Config-IniFiles-2.39/IniFiles.pm

=head1 AUTHOR

Brad Baxter, E<lt>bmb@mail.libs.uga.eduE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2006 by Brad Baxter

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.7 or,
at your option, any later version of Perl 5 you may have available.


=cut
