#---------------------------------------------------------------------
package Ini::Edit::Quote;

use 5.008007;
use strict;
use warnings;
use Carp;

our @ISA = qw();
our $VERSION = '0.01';

# (based on code copied from YAML.pm)

#---------------------------------------------------------------------
# Printable characters for escapes
my %unescapes = 
  (
   z => "\x00", a => "\x07", t => "\x09",
   n => "\x0a", v => "\x0b", f => "\x0c",
   r => "\x0d", e => "\x1b", '\\' => '\\',
  );
   
# change backslash style escape characters to their literal meanings
sub _unescape {
    my ( $to_unescape ) = @_;
    $to_unescape =~ s/\\([never\\fartz]|x([0-9a-fA-F]{2}))/
              (length($1)>1)?pack("H2",$2):$unescapes{$1}/gex;
    return $to_unescape;
}

#---------------------------------------------------------------------
# Parse double quoted string (also regex-like, i.e., /xyz/).
sub _parse_double_quoted {
    my( $to_parse ) = @_;
    if( $to_parse =~  /^\s*"((?:\\"|[^"])*)"\s*$/ ) {
        $to_parse = $1;
        $to_parse =~ s/\\"/"/g;
    }
    elsif( $to_parse =~ m{^\s*/((?:\\/|[^/])*)/\s*$} ) {
        $to_parse = $1;
        $to_parse =~ s{\\/}{/}g;
    }
    else {
        carp "Bad double_quoted string: $to_parse";
    }
    $to_parse = _unescape( $to_parse );
    return $to_parse;
}

#---------------------------------------------------------------------
# Parse single quoted string.
sub _parse_single_quoted {
    my( $to_parse ) = @_;
    if ($to_parse =~ /^\s*'((?:''|[^'])*)'\s*$/) {
        $to_parse = $1;
        $to_parse =~ s/''/'/g;
    }
    else {
        carp "Bad single_quoted string: $to_parse";
    }
    return $to_parse;
}
# Preloaded methods go here.

1;
__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

Ini::Edit::Quote - Perl extension for blah blah blah

=head1 SYNOPSIS

  use Ini::Edit::Quote;
  blah blah blah

=head1 DESCRIPTION

Stub documentation for Ini::Edit::Quote, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.


=head1 SEE ALSO

Mention other useful documentation such as the documentation of
related modules or operating system documentation (such as man pages
in UNIX), or any relevant external documentation such as RFCs or
standards.

If you have a mailing list set up for your module, mention it here.

If you have a web site set up for your module, mention it here.

=head1 AUTHOR

Brad Baxter, E<lt>bmb@galib.uga.eduE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2006 by Brad Baxter

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.7 or,
at your option, any later version of Perl 5 you may have available.


=cut
