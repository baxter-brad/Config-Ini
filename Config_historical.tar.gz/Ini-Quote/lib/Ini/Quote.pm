package Ini::Quote;

=head1 NAME

Ini::Quote - Quoting strings for Ini modules

=cut

use 5.008007;
use strict;
use warnings;
use Carp;
use HTML::Entities ();

use Exporter;
our @ISA = qw( Exporter );
our @EXPORT_OK = qw(
    unescape_for_double_quoted
    escape_for_double_quoted
    as_double_quoted
    as_single_quoted
    as_heredoc
    parse_double_quoted
    parse_single_quoted
    );
our %EXPORT_TAGS = (
    all => [@EXPORT_OK],
    escape => [qw(
        unescape_for_double_quoted
        escape_for_double_quoted
        )],
    );

# subroutines summary:
# unescape_for_double_quoted( $to_unescape, $types );
# escape_for_double_quoted( $to_escape, $types )
# as_double_quoted( $to_quote )
# as_single_quoted( $to_quote )
# as_heredoc( $to_quote, $types, $q, $style, $tag )
# parse_double_quoted( $to_parse, $types )
# parse_single_quoted( $to_parse )

=head1 SYNOPSIS

  use Ini::Quote ':escape';

  binmode(STDOUT, ":utf8"); # to quiet warnings
  my $smiley = qq{\t"smiley":\x{263a}\n};

  $smiley = escape_for_double_quoted( $smiley );
  print $smiley; # literally: \t"smiley":\u263A\n

  $smiley = unescape_for_double_quoted( $smiley );
  print $smiley; # same as: print qq{\t"smiley":\x{263a}\n};

  use Ini::Quote ':all';

  print as_double_quoted( $smiley );
  # literally: "\t\"smiley\":\u263A\n"

  print as_single_quoted( $smiley );
  # same as: print qq{'\t"smiley":\x{263a}\n'};

  print as_heredoc( $smiley, 'EOT', '<<', '"' );
  # literally:
  # <<"EOT"
  # \t"smiley":\u263A
  # EOT

  $smiley =~ s/"/\\"/g; # prepare for parse--needs inner quotes escaped
  print parse_double_quoted( qq{"$smiley"} );
  # same as: print qq{\t"smiley":\x{263a}\n};

  print parse_single_quoted( "'''Hello, World.'''" );
  # 'Hello, World.'

=head1 VERSION

 VERSION: 0.01

=cut

our $VERSION = '0.01';

# more POD after the __END__

#---------------------------------------------------------------------
# Printable characters for escapes (based on YAML Version 1.1 specs)

my %unescapes = 
  (
   0 => "\x00", a    => "\x07", b => "\x08", t => "\x09",
   n => "\x0a", v    => "\x0b", f => "\x0c", r => "\x0d",
   e => "\x1b", '\\' => '\\',   N => "\x85", _ => "\xa0",
   L => "\x{2028}",  P => "\x{2029}",
  );
# reverse hash
my %escapes = map { ord($unescapes{$_}) => $_ } keys %unescapes;

#---------------------------------------------------------------------
# change backslash escapes to their literal meanings
## unescape_for_double_quoted( $to_unescape, $types );
sub unescape_for_double_quoted {
    my ( $to_unescape, $types ) = @_;

    # :slash => \x00,\u0000 ... :html => &#x00;,&#x0000;
    my $slash = $types ? ($types =~ /:slash/) ? 1 : 0 : 1; # default
    my $html  = $types ? ($types =~ /:html/)  ? 1 : 0 : 0;

    $to_unescape =~ s/ \\
        ([PLan\\verb_f0Nt] |
        [ux]([0-9a-fA-F]{4}) |
        x([0-9a-fA-F]{2})
        )/
        (length($1)>4) ? pack("U*",hex($2)) :
        (length($1)>2) ? pack("H2",$3)      :
        $unescapes{$1} /gex if $slash;
    $to_unescape = HTML::Entities::decode( $to_unescape ) if $html;
    $to_unescape;
}

#---------------------------------------------------------------------
## escape_for_double_quoted( $to_escape, $types )
sub escape_for_double_quoted {
    my ( $to_escape, $types ) = @_;

    # :slash => \x00,\u0000 ... :html => &#x00;,&#x0000;
    my $slash = $types ? ($types =~ /:slash/) ? 1 : 0 : 1; # default
    my $html  = $types ? ($types =~ /:html/)  ? 1 : 0 : 0;

    # do html first
    $to_escape = HTML::Entities::encode( $to_escape ) if $html;
    $to_escape = join("",
        map {
            exists $escapes{$_}       ?  # if \n, \t, etc.
            "\\$escapes{$_}"          :  # escaped as \.
            $_ > 255                  ?  # else if wide character
            sprintf("\\u%04X", $_)    :  # escaped as \u....
            chr($_) =~ /[[:^print:]]/ ?  # else if not printable
            sprintf("\\x%02X", $_)    :  # escaped as \x..
            chr($_)                      # else as itself
        } unpack("U*", $to_escape))      # unpack Unicode characters
        if $slash;
    $to_escape;
}

#---------------------------------------------------------------------
## as_double_quoted( $to_quote )
sub as_double_quoted {
    my( $to_quote, $types ) = @_;
    $to_quote = &escape_for_double_quoted; # pass @_ along
    $to_quote =~ s/"/\\"/g;
    qq'"$to_quote"';
}

#---------------------------------------------------------------------
## as_single_quoted( $to_quote )
sub as_single_quoted {
    my( $to_quote ) = @_;
    $to_quote =~ s/'/''/g;
    "'$to_quote'";
}

#---------------------------------------------------------------------
## as_heredoc( $to_quote, $tag, $style, $q, $types )
sub as_heredoc {
    my( $to_quote, $tag, $style, $q, $types ) = @_;
    $tag = '' unless defined $tag;
    $style ||= '<<';
    $q = !defined($q)     ? ''  :
        ($q=~/^\s*["d]/i) ? '"' :
        ($q=~/^\s*['s]/i) ? "'" : '';
    $types ||= '';
    my $chomp = '';
    unless( $to_quote =~ /\n$/ ) {
        $chomp = ':chomp'; $to_quote .= "\n"; }
    if( $tag eq '' ) {
        $style = ($style=~/^\s*{/) ? '{}' : '<<<<'; } #vi}
    if( $q eq '"' ) {
        $to_quote = escape_for_double_quoted( $to_quote, $types );
        $to_quote =~ s/\\n/\n/g; }  # put newlines back in
    else{ $types = ''; }
    my( $begin, $end );
    for( $style ) {
        /{/    and do { $begin = "{$q$tag$chomp$types$q";  $end = $tag };
        /}/    and do { $end = "}$tag"; last };
        /<</   and do { $begin = "<<$q$tag$chomp$types$q"; $end = $tag };
        /<<<</ and do { $end = "<<$tag" } }
    my $t = '';
    if( $to_quote =~ /^\s*$end/m ) {  # end tag found in data?
        $t = 'a';
        while( $to_quote =~ /^\s*${end}_$t\s*/m ) { $t++ }
        $begin =~ s/$chomp$types$q$/_$t$chomp$types$q/; $end .= "_$t" }
    "$begin\n$to_quote$end\n";
}

#---------------------------------------------------------------------
# Parse double quoted string (also regex-like, i.e., /xyz/).
## parse_double_quoted( $to_parse, $types )
sub parse_double_quoted {
    my( $to_parse, $types ) = @_;
    if( $to_parse =~  /^\s*"((?:\\"|[^"])*)"\s*$/ ) {
        $to_parse = $1;
        $to_parse =~ s/\\"/"/g;
    }
    # XXX really do this?
    elsif( $to_parse =~ m{^\s*/((?:\\/|[^/])*)/\s*$} ) {
        $to_parse = $1;
        $to_parse =~ s{\\/}{/}g;
    }
    else {
        croak "Bad double_quoted string: $to_parse";
    }
    $to_parse = unescape_for_double_quoted( $to_parse, $types );
}

#---------------------------------------------------------------------
# Parse single quoted string.
## parse_single_quoted( $to_parse )
sub parse_single_quoted {
    my( $to_parse ) = @_;
    if ($to_parse =~ /^\s*'((?:''|[^'])*)'\s*$/) {
        $to_parse = $1;
        $to_parse =~ s/''/'/g;
    }
    else {
        croak "Bad single_quoted string: $to_parse";
    }
    $to_parse;
}

1;
__END__

=head1 DESCRIPTION

This module is designed to provide Unicode and
other backslash-escaped character support for the
Config::Ini::Edit and Config::Ini::Expanded modules.

If requested, it also will support interpreting
HTML entities in double quoted strings (using
HTML::Entities).

=head1 FUNCTIONS

=over 8

=item escape_for_double_quoted( $to_escape, $types )

Escapes (encodes) unprintable and unicode characters.

 my $e = escape_for_double_quoted( $s );

The parameter, $types, may contain any combination of these
strings: ':slash', ':html'.  If $types is false (e.g., undef
or ''), the default is ':slash', which encodes the following
characters:

 "\x00" as \0     (null)
 "\x07" as \a     (bell)
 "\x08" as \b     (backspace)
 "\x09" as \t     (tab)
 "\x0a" as \n     (new line)
 "\x0b" as \v     (vertical tab)
 "\x0c" as \f     (form feed)
 "\x0d" as \r     (carriage return)
 "\x1b" as \e     (ascii escape)
 '\\'   as \\     (escaped backslash)
 "\x85" as \N     (Unicode next line)
 "\xa0" as \_     (Unicode non-breaking space)
 "\x{2028}" as \L (Unicode line separator)
 "\x{2029}" as \P (Unicode paragraph separator),

other unprintable characters as \xXX, and (wide) Unicode
characters as \uXXXX, where XX and XXXX are the hex code
for the character.

If $types matches /:html/, the string is first encoded
using HTML::entities::encode's defaults, i.e., it will
encode control chars, high-bit chars, and the <, &, >, ' and "
characters. If $types also matches /:slash/, then any
remaining characters from the above table, e.g., \n, \r,
\t, will be encoded as above.

This function is exported in groups :escape and :all, i.e.,

 Use Config::Ini::Quote qw( :escape );
 Use Config::Ini::Quote qw( :all );

=item unescape_for_double_quoted( $to_unescape, $types );

Converts (decodes) escaped text to actual characters.

 $smiley = unescape_for_double_quoted( '\t"smiley":\u263a\n' );

The parameter, $types, may contain any combination of
these strings: ':slash', ':html', as described in
escape_for_double_quoted() above. By default, the codes
in the above table, e.g., \n, \t, etc., and codes of the
form \xXX, \xXXXX, and \uXXXX will be decoded to their
actual characters. (Note that \xXXXX is accepted as a synonym
for \uXXXX.)

If $types matches /:html/, HTML entities will be decoded
using HTML::Entities::decode's defaults. If $types also
matches /:slash/, then other codes, e.g., \n, \t, \r will
be decoded, too.

As implied above, if you use :html, the default escaping
technique, :slash, will be disabled unless you explicitly
include it, too, e.g., $types eq ':html:slash'

This function is exported in groups :escape and :all.

=item as_double_quoted( $to_quote, $types )

Double quotes a string--with character escapes; double quotes
are escaped as \".

 $e = as_double_quoted( $s );

The value returned will begin and end with a double
quote character, (").  Characters in the string will be
escaped (encoded) using escape_for_double_quoted() as
described above, including how the $types parameter works.
Additionally, double quote characters in the string
will be escaped as \".

This function is exported in group :all.

=item as_single_quoted( $to_quote )

Single quotes a string--without character escapes;
single quotes are escaped by doubling: ('').  The value
returned will begin and end with a single quote (').

 $e = as_single_quoted( $s );

This function is exported in group :all.

=item as_heredoc( $to_quote, $tag, $style, $q, $types )

"Quotes" a string using heredoc notation.

 $s = qq{\t"smiley":\x{263a}\n};
 $e = as_heredoc( $s, 'EOT', '<<', '"' );
 # <<"EOT"
 # \t"smiley":\u263A
 # EOT

The second parameter, $tag, is the heredoc tag for 
the begin and end.  If null, the alternate style is
used, e.g., 

 $e = as_heredoc( $s, '', '<<', '"' );
 # <<""
 # \t"smiley":\u263A
 # <<

The third parameter, $style, is one of: '<<', '<<<<',
'{', '{}'.  Examples may explain best:

 $e = as_heredoc( "Hey\n", 'EOT', '<<' );
 # <<EOT
 # Hey
 # EOT

 $e = as_heredoc( "Hey\n", 'EOT', '<<<<' );
 # <<EOT
 # Hey
 # <<EOT

 $e = as_heredoc( "Hey\n", 'EOT', '{' );
 # {EOT
 # Hey
 # EOT

 $e = as_heredoc( "Hey\n", 'EOT', '{}' );
 # {EOT
 # Hey
 # }EOT

The fourth parameter, $q, should match 
/^\s*["d's]/i--["d] meaning double quotish,
['s], single quotish.  Unlike Perl's heredocs,
if $q is not specified, single quotish is
the default.  If double quotish, the text in
the heredoc is escaped using
escape_for_double_quoted( $to_quote, $types )
(but \n is left alone),
otherwise, the text is left alone.  (In neither
case is " changed to \" or ', to ''.)
The appropriate quote is placed around the tag.
(TODO: rewrite that paragraph.)

 $s = qq{one\t"fish"\ntwo\t'fish'\n};
 $e = as_heredoc( $s, 'EOT', '<<', '"' );
 # <<"EOT"
 # one\t"fish"
 # two\t'fish'
 # EOT

 $e = as_heredoc( $s, 'EOT', '<<', "'" );
 # <<'EOT'
 # one	"fish"
 # two	'fish'
 # EOT

 $e = as_heredoc( $s, 'EOT', '<<' );
 # <<EOT
 # one	"fish"
 # two	'fish'
 # EOT

If the string does not end with a newline,
the :chomp modifier is added

 chomp $s;
 $e = as_heredoc( $s, 'EOT', '<<' );
 # <<EOT:chomp
 # one	"fish"
 # two	'fish'
 # EOT

The fifth parameter, $types, is the same as described in
escape_for_double_quoted() above, i.e., it contains
':slash' and/or ':html', defaulting to ':slash'.  This
parameter has meaning only if $q is '"' or 'd' (double
quotish).  The value of $types is passed to
escape_for_double_quoted inside the as_heredoc function,
and is appended to the heredoc tag.  This allows the same
types of quote escapes to be honored when the Ini file
is read later.

    $s = "vis-�-vis Beyonc�'s na�ve\n\tpapier-m�ch� r�sum�";
    $e = as_heredoc( $s, 'EOT', '{}', 'double', ':slash' );
    # {"EOT:chomp:slash"
    # vis-\xE0-vis Beyonc\xE9's na\xEFve
    # \tpapier-m\xE2ch\xE9 r\xE9sum\xE9
    # }EOT

    $e = as_heredoc( $s, 'EOT', '{}', 'double', ':html' );
    # {"EOT:chomp:html"
    # vis-&agrave;-vis Beyonc&eacute;'s na&iuml;ve
    # 	papier-m&acirc;ch&eacute; r&eacute;sum&eacute;
    # }EOT

    $e = as_heredoc( $s, 'EOT', '{}', 'double', ':html:slash' );
    # {"EOT:chomp:html:slash"
    # vis-&agrave;-vis Beyonc&eacute;'s na&iuml;ve
    # \tpapier-m&acirc;ch&eacute; r&eacute;sum&eacute;
    # }EOT


This function is exported in group :all.

=item parse_double_quoted( $to_parse, $types )

Parses a double-quoted string, unescaping escaped characters.

 $s = parse_double_quoted( q{"\t\\"smiley\\":\\u263a\n"} );

This function is exported in group :all.

=item parse_single_quoted( $to_parse )

Parses a single-quoted string; recognizes no escapes except
doubled single quotes: ''.

 $s = parse_single_quoted( "'''Hello, World.'''" );

This function is exported in group :all.

=back

=head1 SEE ALSO

Ini::Edit,
Ini::Expanded

=head1 AUTHOR

Brad Baxter, E<lt>bmb@mail.libs.uga.eduE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2006 by Brad Baxter

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.7 or,
at your option, any later version of Perl 5 you may have available.

=cut
